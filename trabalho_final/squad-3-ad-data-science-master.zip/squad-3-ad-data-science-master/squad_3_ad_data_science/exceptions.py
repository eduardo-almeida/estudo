class ConfigMissException(Exception):
    '''
        @brief Exception for fails on configuration file
    '''
    pass
