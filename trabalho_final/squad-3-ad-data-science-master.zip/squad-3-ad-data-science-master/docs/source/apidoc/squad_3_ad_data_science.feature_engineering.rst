squad\_3\_ad\_data\_science.feature\_engineering module
=======================================================

.. automodule:: squad_3_ad_data_science.feature_engineering
    :members:
    :undoc-members:
    :show-inheritance:
