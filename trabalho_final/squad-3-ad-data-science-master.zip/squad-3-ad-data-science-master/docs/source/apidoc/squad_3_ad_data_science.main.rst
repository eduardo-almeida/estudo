squad\_3\_ad\_data\_science.main module
=======================================

.. automodule:: squad_3_ad_data_science.main
    :members:
    :undoc-members:
    :show-inheritance:
