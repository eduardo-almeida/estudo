API
=======================

.. toctree::
   :maxdepth: 4

   squad_3_ad_data_science
