squad\_3\_ad\_data\_science.exceptions module
=============================================

.. automodule:: squad_3_ad_data_science.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
