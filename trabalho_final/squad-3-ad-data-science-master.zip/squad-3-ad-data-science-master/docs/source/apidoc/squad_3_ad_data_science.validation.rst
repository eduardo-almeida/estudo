squad\_3\_ad\_data\_science.validation module
=============================================

.. automodule:: squad_3_ad_data_science.validation
    :members:
    :undoc-members:
    :show-inheritance:
