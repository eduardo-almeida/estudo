squad\_3\_ad\_data\_science package
===================================

Submodules
----------

.. toctree::

   squad_3_ad_data_science.config
   squad_3_ad_data_science.exceptions
   squad_3_ad_data_science.feature_engineering
   squad_3_ad_data_science.main
   squad_3_ad_data_science.model_training
   squad_3_ad_data_science.recomendations
   squad_3_ad_data_science.validation

Module contents
---------------

.. automodule:: squad_3_ad_data_science
    :members:
    :undoc-members:
    :show-inheritance:
