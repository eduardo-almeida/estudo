squad\_3\_ad\_data\_science.config module
=========================================

.. automodule:: squad_3_ad_data_science.config
    :members:
    :undoc-members:
    :show-inheritance:
