squad\_3\_ad\_data\_science.recomendations module
=================================================

.. automodule:: squad_3_ad_data_science.recomendations
    :members:
    :undoc-members:
    :show-inheritance:
