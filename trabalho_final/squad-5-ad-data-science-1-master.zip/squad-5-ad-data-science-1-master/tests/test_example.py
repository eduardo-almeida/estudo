def test_example(fixture_example):
    assert fixture_example == 42
