# Repositório Squad 2

[Canal da squad](https://chat.codenation.com.br/group/aceleradev-xp-ds-squad2) | [Projeto](https://www.codenation.dev/private-journey/adxp-datascience-joinville-2/challenge/ml-leads)

## Integrantes
Mateus Nicoladelli

[Rhoger Anacleto](http://github.com/rhogeranacleto)

[Tiago Wutzke de Oliveira](https://www.linkedin.com/in/tiago-wutzke-de-oliveira-42174239/) 




