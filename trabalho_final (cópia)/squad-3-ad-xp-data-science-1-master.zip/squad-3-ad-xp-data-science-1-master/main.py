def loadsmart():
    raise NotImplementedError() 
