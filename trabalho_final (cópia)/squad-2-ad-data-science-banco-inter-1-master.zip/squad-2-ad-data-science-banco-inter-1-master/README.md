# squad-2-ad-data-science-banco-inter-1

## Setando o ambiente virtual

1. Instale o virtualenv e crie o ambiente virtual
    * `pip install virtualenv`
    * `virtualenv projetoFinal`

2. Ative o ambiente virtual criado
    * `cd projetoFinal`
    * `source bin/activate`

3. Vincule o projeto ao repositório do Squad
	* `git init`
	* `git remote add origin https://github.com/codenation-dev/squad-2-ad-data-science-banco-inter-1.git`
	* `git pull`

4. Instale as dependencias do projeto
	* `pip install -r requirements.txt`

---
