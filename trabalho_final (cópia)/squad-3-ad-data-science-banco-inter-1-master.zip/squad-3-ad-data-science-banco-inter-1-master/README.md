# squad-3-ad-data-science-banco-inter-1

para ter acesso aos datasets, que ultrapassaram 100MB no github, clique no link abaixo:

https://drive.google.com/file/d/1LBGgPce44MTQMznbEykvwnlJs3SYJoJi/view?usp=sharing
