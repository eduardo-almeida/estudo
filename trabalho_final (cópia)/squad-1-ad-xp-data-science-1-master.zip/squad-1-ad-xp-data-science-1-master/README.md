# ADxp Data Science - Squad 1
## Integrantes:
[@Alice-Scholze][Alice]

[@SilvioFerrari][Silvio]

[@KauanAmarante][Kauan]

  [Alice]: https://github.com/Alice-Scholze 
  [Silvio]: https://github.com/SilvioFerrari
  [Kauan]: https://github.com/KauanAmarante
